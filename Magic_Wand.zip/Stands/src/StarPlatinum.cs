﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DuckGame.Magic_Wand
{
    internal class StarPlatinum : Thing
    {
        private SpriteMap sprite;
        public Duck vladelec = null;
        private int direct = 0;
        public StarPlatinum(float xpos, float ypos) : base(xpos, ypos)
        {
            this.sprite = new SpriteMap(GetPath("SPTW_punch"), 32, 32);
            this.sprite.AddAnimation("SPTW_punch", 1f, true, new int[] { 0, 1, 2, 3, 4 });
            this.sprite.SetAnimation("SPTW_punch");
            base.graphic = this.sprite;
        }

        public override void Update()
        {
            if (this.vladelec == null)
            {
                base.Update();
                return;
            }
            foreach (Duck duck in Level.CheckCircleAll<Duck>(this.position, 25f))
            {
                if (this.vladelec == duck)
                {
                    continue;
                }
                duck.GoRagdoll();
                duck._destroyed = true;
            }
            if (!vladelec.moveLock && vladelec.inputProfile.Pressed("RIGHT"))
            {
                this.sprite.flipH = false;
                direct = 1;
            }

            if (!vladelec.moveLock && vladelec.inputProfile.Pressed("LEFT"))
            {
                this.sprite.flipH = true;
                direct = -1;
            }
            this.x = this.vladelec.x + 12 * direct;
            this.y = this.vladelec.y - 15;
            base.Update();
        }
    }
}
